// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>
const eResult = document.querySelector(".js-result");
const eNumbers = document.querySelectorAll(".js-number");
const eOperators = document.querySelectorAll(".js-operator");
let prevNumber = null,
  nextNumber = null,
  result = null;
let operator = null;

function getResult(curOper) {
  if (curOper == "+") {
    result = parseInt(prevNumber) + parseInt(nextNumber);
  } else if (curOper == "-") {
    result = parseInt(prevNumber) - parseInt(nextNumber);
  } else if (curOper == "*") {
    result = parseInt(prevNumber) * parseInt(nextNumber);
  } else if (curOper == "/") {
    result = parseInt(prevNumber) / parseInt(nextNumber);
  }
  // console.log(prevNumber, operator, nextNumber, result);
  eResult.innerText = result;
  prevNumber = result;
  nextNumber = null;
  //operator = null;
}
function reset() {
  eResult.innerText = "";
  prevNumber = null;
  nextNumber = null;
  operator = null;
  result = null;
}

function clickNumberHandle(event) {
  eResult.innerText = event.target.innerText;
  if (prevNumber === null) {
    prevNumber = parseInt(event.target.innerText);
  } else if (operator !== null) {
    // 숫자2번 + 연산자  넣을때 계산을 막기위함
    nextNumber = parseInt(event.target.innerText);
  }
}
function clickOperatorHandle(event) {
  // console.log(prevNumber, operator, nextNumber, result, "^^");

  if (event.target.innerText === "C") {
    reset();
  } else if (
    // getResult
    event.target.innerText === "=" &&
    prevNumber != null &&
    nextNumber != null
  ) {
    getResult(operator);
  } else if (
    event.target.innerText != "=" &&
    prevNumber != null &&
    nextNumber != null
  ) {
    // getResult by operation
    operator = event.target.innerText;
    getResult(operator);
  } else {
    //  insert operation
    operator = event.target.innerText;
  }
}
function init() {
  eNumbers.forEach(function (eNumber) {
    eNumber.addEventListener("click", clickNumberHandle);
  });

  eOperators.forEach(function (eOperator) {
    eOperator.addEventListener("click", clickOperatorHandle);
  });
}

init();
