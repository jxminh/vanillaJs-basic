// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>

const eMaxNumber = document.querySelector(".js-maxNumber");
const eRange = document.querySelector(".js-range");
const eButton = document.querySelector(".js-play");
const eGuessNumber = document.querySelector(".js-guessNumber");
const eResult = document.querySelector(".result");

function handleChangeRange(event) {
  eMaxNumber.innerText = eRange.value;
}
function handleSubmit(event) {
  const nRandomNumber = Math.round(Math.random() * eRange.value);
  const nInputNumber = eGuessNumber.value;
  let sResult = "";
  if (parseInt(nInputNumber) === nRandomNumber) {
    sResult = "win";
  } else {
    sResult = "lose";
  }
  event.preventDefault();
  console.log(parseInt(nInputNumber), nRandomNumber);
  eResult.innerText = `You choise: ${nInputNumber}, the machine chose: ${nRandomNumber} \n You ${sResult}`;
}

function init() {
  eRange.addEventListener("change", handleChangeRange);
  eButton.addEventListener("click", handleSubmit);
}
init();
