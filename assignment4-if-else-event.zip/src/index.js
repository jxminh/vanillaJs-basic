// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>
const body = document.querySelector("body");
const colours = ["#e74c3c", "#3498db", "#f1c40f"];

function handleResize() {
  const widthValue = window.innerWidth;
  if (widthValue <= 700) {
    body.style.backgroundColor = colours[0];
  } else if (widthValue <= 1000) {
    body.style.backgroundColor = colours[1];
  } else {
    body.style.backgroundColor = colours[2];
  }
}
function init() {
  window.addEventListener("resize", handleResize);
}
init();
