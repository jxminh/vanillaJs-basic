// <⚠️ DONT DELETE THIS ⚠️>
import "./styles.css";
// <⚠️ /DONT DELETE THIS ⚠️>

const select = document.querySelector("select");
const reset = document.querySelector(".js-reset");
const COUNTRY_LS = "country";

function saveCountry(value) {
  localStorage.setItem(COUNTRY_LS, value);
  //console.log(localStorage.getItem(COUNTRY_LS));
}

function handleSelect(event) {
  const selectedCountry = event.target.value;
  saveCountry(selectedCountry);
  console.log(selectedCountry);
  event.preventDefault();
}

function selectCountry(text) {
  select.value = text;
}

/* Reset */
function handleReset() {
  localStorage.removeItem(COUNTRY_LS);
  select.value = "";
}

function loadCountry() {
  const countryName = localStorage.getItem(COUNTRY_LS);
  if (countryName === null) {
    //select.addEventListener("change", handleSelect);
  } else {
    selectCountry(countryName);
  }
  select.addEventListener("change", handleSelect); // 선택후에도 선택가능;
  reset.addEventListener("click", handleReset);
}
function init() {
  loadCountry();
}

init();
